package com.centene.helloApp;

import org.json.simple.JSONObject;

public class HelloCenteneService {

	public JSONObject printHelloCentene() {
		JSONObject helloCentene = new JSONObject();
		helloCentene.put("message", "Hello Centene !!!");
		return helloCentene;
	}
}
