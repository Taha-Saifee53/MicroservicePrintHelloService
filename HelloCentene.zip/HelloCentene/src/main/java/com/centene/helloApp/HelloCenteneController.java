package com.centene.helloApp;

import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloCenteneController {

	@GetMapping(value = "/hello/centene",produces = "application/json")
	public ResponseEntity<Object> helloCentene(){
		
		HelloCenteneService serviceObj = new HelloCenteneService();
		JSONObject printCentene = new JSONObject();
		printCentene = serviceObj.printHelloCentene();
		return new ResponseEntity(printCentene,HttpStatus.OK);
	}
}
